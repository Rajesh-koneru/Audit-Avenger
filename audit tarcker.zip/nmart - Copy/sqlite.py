from flask import Flask, render_template,request,flash,session
from flask_sqlalchemy import SQLAlchemy
# Initialize the Flask app and database
vulner = Flask(__name__)
vulner.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user1.db'  # SQLite for simplicity
vulner.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Disable modification tracking for performance

# Initialize SQLAlchemy
db = SQLAlchemy(vulner)
vulner.secret_key='hello'

# Define the database model
class User(db.Model):
    username = db.Column(db.String(120), primary_key=True, nullable=False)
    phone = db.Column(db.Integer,unique=False )
    email = db.Column(db.String(120), unique=True, nullable=False)
    password=db.Column(db.Integer, nullable=True, unique=False)
    def __repr__(self):
        return f"User('{self.username}', '{self.email}')"

# Create the database and tables
with vulner.app_context():
    db.create_all()

@vulner.route('/')
def registration():
    return render_template('sigup.html')
# Route to add a new user
@vulner.route("/signup",methods=['post'])
def add_user():
    name=request.form['id']
    phone=request.form['phone']
    mail=request.form.get('email')
    password=request.form.get('pass')
    user = User( username=name ,phone=phone,email=mail ,password=password)
    db.session.add(user)  # Add to sess
    db.session.commit()
    flash('you are registered')
    return render_template('page.html')
# Route to query users
@vulner.route("/users")
def users():
    data = User.query.all()  # Query all users
    for i in data:
        print(i)
    return render_template('test.html',name=data)#   Render users in a template and getting dtabase data on the page
@vulner.route('/drop',methods=['post','get','delete'] )
def remov():
    data=User.query.all()
    for user in data:
        db.session.delete(user)
    db.session.commit()
    new_tab=User.query.all()
    message='successful deleted'
    return render_template('test.html',name=new_tab,message=message)

if __name__ == "__main__":
    vulner.run(debug=True)
