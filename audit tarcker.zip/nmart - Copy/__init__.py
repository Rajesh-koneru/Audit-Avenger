from flask import Flask

vulner=Flask('__name__')

from login import login
vulner.register_blueprint(login)
from login import sig
vulner.register_blueprint(sig)

vulner.run()
