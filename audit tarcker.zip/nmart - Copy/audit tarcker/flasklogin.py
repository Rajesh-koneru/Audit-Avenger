from flask import Flask , render_template , redirect,request,abort
import sqlite3
from flask_login import *

app=Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"  # Redirect unauthorized users to this view
class Users(UserMixin):
    conn = sqlite3.connect('auditTracker.db')
    pointer = conn.cursor()
    sql = f'''select * from Users '''
    pointer.execute(sql)
    print( '\n ',pointer.fetchmany(5))
    def get_by_id(user_id):
        conn = sqlite3.connect('auditTracker.db')
        pointer = conn.cursor()
        sql=f'''select name ,age from users where id={user_id}; '''
        pointer.execute(sql)
        data=pointer.fetchone()
        print(data)
        return data
@login_manager.user_loader
def load_user(user_id):
    return Users.get_by_id(user_id)
load_user(7)
app.run()


